# @pw/ui

Design tokens for the apps Precision Weave builds. The source is W3C Design Tokens (DTCG 2025.10) JSON. Style Dictionary builds it into CSS custom properties, flat JSON, a JS module with literal types, and a Tailwind v4 theme. Every build is checked for WCAG contrast in light and dark mode.

## Use in a project

The package is private, on the GitHub Packages registry of the `precision-weave` org. It installs as `@pw/ui`. Installing needs the environment variable `NODE_AUTH_TOKEN` and a two-line `~/.npmrc`, and the install fails if the variable is not set. The setup, CI, upgrade and failures are in [the install guide](.claude/skills/pw-ui/guides/install.md). In the project root:

```sh
grep -qs '^@precision-weave:registry=' .npmrc || printf '\n@precision-weave:registry=https://npm.pkg.github.com\n' >> .npmrc
pnpm add @pw/ui@npm:@precision-weave/ui
pnpm exec pw-ui install
```

`pw-ui install` copies the `pw-ui` skill to `.claude/skills/pw-ui/`, writes nothing else and never overwrites an edited file. To try a framework the system does not cover yet, see [the extension guide](.claude/skills/pw-ui/guides/extend.md).

## Use

Plain CSS:

```css
@import "@pw/ui/tokens.css";
.card { background: var(--pw-surface); color: var(--pw-text); border-radius: var(--pw-r-md); }
```

Light is the default. Dark applies with `data-theme="dark"` on `<html>`, or from the system setting when no choice is set. `data-theme="light"` forces light.

React and TypeScript:

```ts
import { tokens, cssVar } from "@pw/ui/tokens";
tokens.brand.value;   // "#2C3396"
tokens.brand.dark;    // "#4351D0"
cssVar("brand");      // "var(--pw-brand)"
```

Tailwind v4:

```css
@import "tailwindcss";
@import "@pw/ui/tokens.css";
@import "@pw/ui/tailwind.css";
```

Utilities then read the live variables, so `bg-brand`, `text-text-2`, `rounded-md`, `shadow-2` and `p-4` follow the mode and the theme. The Tailwind theme replaces Tailwind's default text sizes, spacing, radii, shadows and breakpoints with this system's scale.

Theme:

```css
@import "@pw/ui/themes/precision-weave-neon.css";   /* replaces tokens.css, same variable names */
@import "@pw/ui/components.css";
@import "@pw/ui/styles/glass.css";           /* the theme's style preset, when it has one */
```

`@pw/ui/brands/<name>.css` still resolves to the theme file.

## React

```tsx
import { ThemeProvider, ToastProvider, TooltipProvider, AppShell, TopBar, Brand, SideNav, SideNavGroup, SideNavItem,
         PageHeader, Card, Field, Input, FormSection, useDirtyForm, DataTable, Dialog, ConfirmDialog, Menu, MenuItem,
         Message, Composer, DraftReview } from "@pw/ui/react";
```

Every component renders the CSS classes from `components.css` and adds behaviour where it is needed: dialogs, drawers, menus, popovers, tooltips, toasts, switches and progress come from Radix; icons are Lucide. Wrap the app in `ThemeProvider`, `ToastProvider` and `TooltipProvider`. Router links pass `asChild` to `NavLink`, `SideNavItem`, `ListRow` and `Brand`. `useDirtyForm` with `FormSection` is the inline-save pattern: edits stay local until Save, with a saved confirmation and an unsaved-changes guard. The full list of exports is in `react/index.ts`; each has a JSDoc line saying when to use it.

## Layout

```
tokens/
  primitive/      neutral ramp, type, space, radius, motion, breakpoints
  semantic/       colour and shadow roles: light.json and dark.json define the same tokens
  component/      control sizes; control.touch.json overrides them for touch screens
  styles/<name>/  style preset tokens: light.json and dark.json define the same tokens
themes/           theme sources: seeds and values over the tokens, expanded by bin/lib/theme.mjs
build/build.ts    Style Dictionary build, then every theme through the resolver
src/styles/       style preset CSS, loaded after components.css
src/css/          component CSS partials, built into dist/components.css
react/            React components, compiled by tsc into dist/react
docs/ and site/   documentation source and the generated site (serve with `just start`)
checks/           contrast, golden, CSS lint, and Playwright screenshot and axe checks over the site
dist/             generated, not committed: tokens.{css,json,js,d.ts}, components.css, tailwind.css, themes/<name>.*, styles/<name>.*, react/
reference/        the style guide mockup the tokens were taken from, and its explorer
```

## Naming

A token's first path segment is its category and is dropped from the CSS name: `color.brand` is `--pw-brand`, `space.sp-4` is `--pw-sp-4`, `component.ctl-h` is `--pw-ctl-h`. Names must be unique across categories; the build fails on a collision.

Values use the DTCG 2025.10 shapes: colours are `{ colorSpace: "srgb", components: [r, g, b], alpha, hex }`, dimensions are `{ value, unit }`, shadows are arrays of shadow objects, and `motion.ease` is a transition. The build emits hex, `rgba()`, `px`, `rem` and CSS shorthand.

## Change a token

1. Edit the JSON in its layer. A colour or shadow role lives in both `semantic/light.json` and `semantic/dark.json`.
2. Run `pnpm build`, then `pnpm check`.
3. Commit the source. `dist/` is generated and not committed. CI fails if `site/` or the skill references are stale.

The build fails when light and dark define different sets, when a style preset's two files differ, when a theme file has a problem (an unknown token, a token themes may not set, a bad value), or when a reference is broken. The checks fail when any contrast pair misses its target (4.5:1 text, 3:1 boundaries and focus, 1.5:1 visible borders) or when `dist/tokens.css` no longer reproduces the reference mockup's values.

## Themes

A theme is `themes/<name>.json`: the theme it extends, a style preset, seed colours that expand into the brand, accent and AI roles, and explicit values that win over the seeds. `bin/lib/theme.mjs` resolves it deterministically, and the build writes `dist/themes/<name>.{css,json,js,d.ts}`. `pnpm check` runs the contrast pairs on every theme. Themes may set colours, shadows, chart colours, radii, fonts and style preset tokens. Spacing, type sizes, control sizes and motion stay as the base.

`precision-weave` is the base system and sets nothing. `west-highland-chamber-of-commerce` is a client theme (orange, blue and purple on navy-tinted neutrals, Inter, square corners). `precision-weave-glass` (navy and gold) and `precision-weave-neon` use the glass style preset (`tokens/styles/glass/`, `src/styles/glass.css`).

Change and create themes with `node bin/pw-ui.mjs theme list|show|check|new|set|unset|fix`. The full process is in [the themes guide](.claude/skills/pw-ui/guides/themes.md).

## Commands

```
pnpm build        # tokens/, src/css/, docs/ -> dist/ and site/
pnpm check        # contrast, golden and CSS lint over dist/
pnpm build:react  # react/ -> dist/react
pnpm test:react   # vitest
pnpm test:ui      # Playwright: axe, overflow and screenshots of every page in both modes
pnpm test         # all of the above
```

Needs Node 22.18 or later, which runs the TypeScript scripts directly.

## Operate

Runbooks for packaging, releasing and extending this repository are in [ops/](ops/README.md). The `just` targets are the interface: `just --list`.
