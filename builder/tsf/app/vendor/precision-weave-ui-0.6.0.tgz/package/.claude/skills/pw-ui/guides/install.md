# Install pw-ui in a project

The package is private. It lives in the GitHub Packages registry of the `precision-weave` org as `@precision-weave/ui` and installs as `@pw/ui`. Imports always say `@pw/ui`.

## 1. Registry access (once per machine)

The environment variable `NODE_AUTH_TOKEN` is mandatory. `~/.npmrc` reads the token from it, and npm and pnpm fail if it is not set, on every machine, server and CI job that installs the package.

1. Put these two lines in `~/.npmrc`. Type `${NODE_AUTH_TOKEN}` literally, npm expands it:
   ```
   @precision-weave:registry=https://npm.pkg.github.com
   //npm.pkg.github.com/:_authToken=${NODE_AUTH_TOKEN}
   ```
2. Export `NODE_AUTH_TOKEN` in the environment that runs the install, for example from `~/.zshenv`. The value is a classic token with `read:packages`: create one at https://github.com/settings/tokens/new?scopes=read:packages&description=pw-packages-read&default_expires_at=none. Where something else supplies the credential on the wire, such as a proxy that injects it, any non-empty value is enough.
3. Use a current Node. Node 24 with npm 11 is tested. npm 9.2 fails with `407` behind a proxy that needs credentials.

## 2. Install (project root)

```sh
grep -qs '^@precision-weave:registry=' .npmrc || printf '\n@precision-weave:registry=https://npm.pkg.github.com\n' >> .npmrc
pnpm add @pw/ui@npm:@precision-weave/ui
pnpm exec pw-ui install
```

The first command adds one line to the project `.npmrc` if it is missing and keeps every other line. The second adds the dependency. The third copies this skill to `.claude/skills/pw-ui/`. Nothing else is written, running the three again changes nothing, and a skill file you edited is kept (exit 3; `pnpm exec pw-ui install --force` replaces it).

`pw-ui install` prints the peer packages the project lacks. Add them as it says.

## 3. Use

Plain CSS, in the entry stylesheet:

```css
@import "@pw/ui/tokens.css";
@import "@pw/ui/components.css";
```

Tailwind v4 projects use:

```css
@import "tailwindcss";
@import "@pw/ui/tokens.css";
@import "@pw/ui/tailwind.css";
@import "@pw/ui/components.css";
```

React, minimal page:

```tsx
import { createRoot } from "react-dom/client";
import { ThemeProvider, ToastProvider, TooltipProvider, TopBar, Brand, AppShell, PageHeader, Card, Button } from "@pw/ui/react";

createRoot(document.getElementById("root")!).render(
  <ThemeProvider>
    <ToastProvider>
      <TooltipProvider>
        <TopBar brand={<Brand name="Example" />} />
        <AppShell>
          <PageHeader title="Hello" description="Built on pw-ui." />
          <Card title="Status"><Button>Save changes</Button></Card>
        </AppShell>
      </TooltipProvider>
    </ToastProvider>
  </ThemeProvider>,
);
```

Then follow `SKILL.md`. Check styling with:

```sh
pnpm exec pw-ui-lint src
```

## CI

Add the token as a repository secret once per project:

```sh
gh secret set PW_PACKAGES_TOKEN --repo precision-weave/<repo>
```

Before the install step in the workflow:

```yaml
- name: Authenticate to GitHub Packages
  run: npm config set //npm.pkg.github.com/:_authToken "$PW_PACKAGES_TOKEN"
  env:
    PW_PACKAGES_TOKEN: ${{ secrets.PW_PACKAGES_TOKEN }}
- run: pnpm install --frozen-lockfile
```

## Upgrade

```sh
pnpm up @pw/ui --latest
pnpm exec pw-ui install
pnpm exec pw-ui ext check
pnpm exec pw-ui-lint src
```

`--latest` is needed while the version is below 1.0. Return to an earlier version with `pnpm add @pw/ui@npm:@precision-weave/ui@X.Y.Z` and `pnpm exec pw-ui install --force`.

## Failures

| Symptom | Fix |
|---|---|
| `401` or `403` on install | `NODE_AUTH_TOKEN` is not set in this environment (unset gives `401`), `~/.npmrc` lacks the two lines, or the token lacks `read:packages`. Redo step 1. |
| `404` on `@precision-weave/ui` | The project `.npmrc` lacks the `@precision-weave:registry` line. Run the first install command. |
| `pw-ui install` exits 3 | A skill file was edited locally. Keep it, or run `pnpm exec pw-ui install --force`. |
