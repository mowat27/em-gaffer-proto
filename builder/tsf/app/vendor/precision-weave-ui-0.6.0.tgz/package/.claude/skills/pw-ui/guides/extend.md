# Try a new framework in a project, then promote it

A framework is a stack or technique that pw-ui is applied through: Datastar, Hugo, Vue, htmx, web components. Components and one-off screens are not frameworks. They live in project code.

Check first: `pnpm exec pw-ui ext list`. If the framework is listed with scope `package`, it is supported. Read its reference and import its code from `@pw/ui/frameworks/<name>/`.

## Try it (nothing outside this project changes)

Run in the project root. `pw-ui install` must have run (see [install.md](install.md)).

1. Scaffold:
   ```sh
   pnpm exec pw-ui ext new <name>
   ```
   This creates `.pw-ui/frameworks/<name>/ext.json` and `reference.md`. It refuses a name that already exists or is already supported.
2. Edit `ext.json`. `title` is the display name. `summary` and `applies` are one line each, at most 140 characters. `applies` says when an agent should read the reference. Leave `status` as `experimental`.
3. Write `reference.md`. Keep the title line and the sections `## Setup`, `## Patterns` and `## Checks`; the scaffold also has `## When to use`, which you should fill in. Say how each pw-ui pattern maps to the stack, with markup that uses `pw-` classes and `--pw-` tokens. Never add colours or sizes.
4. Put any code the framework needs in `.pw-ui/frameworks/<name>/src/` and an optional runnable page in `example/`. Import project-local files by relative path, for example `@import "../.pw-ui/frameworks/<name>/src/<name>.css";`.
5. Validate:
   ```sh
   pnpm exec pw-ui ext check
   pnpm exec pw-ui-lint .pw-ui <directories that hold your pages and styles>
   ```
   If the lint summary says `0 files`, nothing was checked: name directories that exist.
6. Build a page with it. `ext check` validates the structure and lints `src/` and `example/`; it cannot judge the content. Agents working in this project find the framework through `pnpm exec pw-ui ext list`.

Edit the reference as you learn. Commit `.pw-ui/` with the project.

## Promote it to pw-ui

Do this when the framework worked in a project and will be reused. Run it in the project root. It needs git access to the pw-ui repository and nothing else: no checkout, no path, no branch.

1. Promote:
   ```sh
   pnpm exec pw-ui ext promote <name>
   ```
   It validates the framework, clones the pw-ui repository into a new temporary directory, copies the framework to `frameworks/<name>/` with `status` set to `supported`, adds a `## X.Y.Z` heading (the next minor version) to `CHANGELOG.md`, and commits on `main`. It never pushes. It prints the directory and the version. `--version X.Y.Z` sets the version. `--repo <dir>` uses an existing checkout on a clean, current `main` instead of cloning.
2. Release, in the directory it printed. This tests, tags and pushes `main`, and CI publishes. Whoever has push access to the repository runs it:
   ```sh
   just install && just release X.Y.Z
   ```
3. In each project that uses it:
   ```sh
   pnpm up @pw/ui --latest
   pnpm exec pw-ui install
   pnpm exec pw-ui ext check
   ```
   `ext check` says `<name> is supported in @pw/ui X.Y.Z`. If the framework has a `src/`, replace imports of `.pw-ui/frameworks/<name>/src/` with `@pw/ui/frameworks/<name>/`. Then delete `.pw-ui/frameworks/<name>/`; the reference is now at `.claude/skills/pw-ui/references/frameworks/<name>.md`.

## Add one straight to pw-ui

In a pw-ui checkout, on `main`: `node bin/pw-ui.mjs ext new <name> --to frameworks`, fill it in, set `status` to `supported`, `just test`, then release as above.
