# Themes: change one, derive one, import one

A theme is a small file of choices, `themes/<name>.json` in the pw-ui repository. A deterministic resolver (`bin/lib/theme.mjs`) expands it over the base tokens into every value of both modes. The build writes `dist/themes/<name>.{css,json,js,d.ts}`, and the checks run the contrast pairs on the result. Edit the choices, never the output.

Themes are edited in the pw-ui repository. In a project, `pnpm exec pw-ui theme list|show|check` read the themes the installed package ships. To change one, work in the repository (`node bin/pw-ui.mjs theme ...`) and release.

## What a theme file holds

```json
{
  "title": "Precision Weave Neon",
  "description": "One or two sentences on the look.",
  "extends": "precision-weave",
  "style": "glass",
  "seeds": {
    "brand": { "light": "hsl(175 81% 41%)", "dark": "hsl(176 65% 50%)" },
    "accent": "brand",
    "ai": { "light": "hsl(332 78% 69%)", "dark": "hsl(308 80% 54%)" },
    "ai-to": { "light": "hsl(318 78% 69%)", "dark": "hsl(294 80% 54%)" }
  },
  "tokens": {
    "canvas": { "light": "#EEF4F5", "dark": "#050708" },
    "r-md": "18px",
    "ai-glow": 0.8
  }
}
```

1. `extends` is the theme it starts from. Changes to the parent flow into the child. `precision-weave` is the base system itself and sets nothing.
2. `style` is the style preset: `flat` (the components as they are) or a preset in `tokens/styles/<name>/`. The style is inherited from the parent theme. Presets and their tokens are listed in [../references/themes.md](../references/themes.md).
3. Each seed expands into a family of roles, and the derived colours are walked in lightness until they meet their contrast pairs:
   - `brand` sets brand, its hover, active, border, soft, text, link, focus and surface-selected.
   - `accent` and `ai` each set a fill, the text on it, soft, tint, border and text colours.
   - `ai-to` is the end of the AI gradient.
   - A seed value may name another seed (`"accent": "brand"`).
4. `tokens` sets values by CSS name without `--pw-`, and these win over seeds. A value may name another token to follow it: `"accent-text": "{brand-text}"` stays equal to `brand-text`, including in themes that extend this one and change the brand. Themes may set colours, shadows, chart colours, radii, fonts and style preset tokens. Spacing, type sizes, control sizes and motion stay as the base.
5. Any value is either one value for both modes or `{ "light": ..., "dark": ... }`. Colours may be hex, `rgb()` or `hsl()`. Seeds keep whole-number HSL, so `hsl()` is exact and other formats are rounded.
6. A token not set by any theme follows its base definition. The AI tokens follow accent unless a theme sets `ai`.

## Commands

All take `--json`. In the repository, run them as `node bin/pw-ui.mjs theme ...`.

| Command | Does |
|---|---|
| `pw-ui theme list` | Themes, what each extends, and its style. |
| `pw-ui theme show <name> [--all]` | Every value the theme changes in both modes, with its source: `set`, `seed <name>`, `follows <token>`, or the parent theme. Also lists derived colours that were walked to meet contrast. `--all` includes the values it inherits from the base. |
| `pw-ui theme check [name...]` | File problems and contrast failures. Exit 1 if there are any. |
| `pw-ui theme new <name> --from <theme> [--title "..."]` | Create a theme that extends another. |
| `pw-ui theme set <name> key=value ...` | Set values, check the result, and write the file. A key is a token (`canvas`), a token in one mode (`canvas.dark`), a seed (`seed.brand`, `seed.ai.light`) or a field (`title`, `description`, `extends`, `style`). If any value is invalid, nothing is written. |
| `pw-ui theme unset <name> key ...` | Remove values, so they fall back to the parent theme. |
| `pw-ui theme fix <name> [--dry-run]` | For each colour the theme sets that fails a contrast pair, change its lightness only as far as it takes to pass, and write the result. Order rules (dark layers getting lighter, hover stronger than rest) are reported, not fixed. |

## Change a theme

1. Make the change with `set`, for example `pw-ui theme set precision-weave-neon seed.ai.light="hsl(330 80% 66%)" r-md=16px`. You can also edit the JSON directly and then run `check`.
2. If `check` reports contrast failures:
   - Run `fix --dry-run` to see the nearest passing values.
   - If they keep the intent, run `fix`. If they don't, choose other values.
   - For order failures, set the layers yourself.
3. Run `show <name>` to review what changed, including derived colours that were walked.
4. Run `pnpm build`, then `pnpm check`. Look at the theme on the documentation site: run `just start`, then pick the theme in the top bar and check both modes. `pnpm test:ui` saves screenshots of the glass theme in both modes to `screenshots/`.
5. Commit the theme file. `dist/` is generated.

## Derive a new theme

Use `pw-ui theme new <client> --from <closest theme>`, then set only what differs: usually `seed.brand`, sometimes `seed.ai` and a few tokens. Leave everything else inherited, so it follows fixes made to the parent.

## Import from a palette, a web page or a design

The resolver is deterministic. Mapping colours to roles takes judgement, and that part is yours:

1. Collect the source colours.
   - A palette or brand guide: take its values.
   - A web page: open it with Playwright and read the computed colours of the page background, cards, body text, primary button, links and focus ring, plus the fonts.
   - An image: sample it.
2. Map the colours to roles:
   - The primary action colour is `seed.brand`.
   - A second hue for AI is `seed.ai`. Without one, AI follows accent.
   - The page and card backgrounds are `canvas` and `surface`.
   - Body text is `text`.
   - Give dark mode its own values. Lift dark surfaces, never pure black.
3. Create the theme with `new`, apply the values with `set`, then run `check` and `fix` until it is clean.
4. Pick a style. Use `flat` unless the source has glass, glow or another treatment a preset provides. A preset that does not exist yet is new CSS in `src/styles/<name>.css` with its tokens in `tokens/styles/<name>/`. That is a design-system change, so propose it first.

## Use a theme in an app

```css
@import "@pw/ui/themes/<name>.css";   /* instead of tokens.css */
@import "@pw/ui/components.css";
@import "@pw/ui/styles/<style>.css";  /* only when the theme has a style preset */
```

The theme file's header names its style. A glass theme with a display font (`font-display`) needs that font loaded by the app, as the base needs IBM Plex. `@pw/ui/brands/<name>.css` still resolves to the theme file for apps that used the old path.
