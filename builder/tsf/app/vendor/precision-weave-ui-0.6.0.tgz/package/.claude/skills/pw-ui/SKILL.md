---
name: pw-ui
description: Build UI for Precision Weave apps with the @pw/ui design system (tokens, plain CSS components, React components on Radix, AI interaction patterns). Use when creating or changing screens, components, styles, themes, forms, tables, dialogs, chat or agent UI in a Precision Weave app, when the user mentions pw-ui, design tokens or --pw- variables, or asks for UI consistent with the Precision Weave design system. Also use when installing or upgrading @pw/ui in a project, adding a framework extension such as Datastar, or creating, changing or importing a theme (client colours, a palette, a web page's look, style presets such as glass).
---

# pw-ui

Build screens on the Precision Weave design system. People use these apps for hours, so the system is calm: one action colour (indigo) for buttons, links and focus, saffron for where you are and for AI, cool white neutrals, room to hit every control. Agents build most of the apps, so the system is machine-checked: tokens are the only source of colour and size, and the lint fails on anything else.

## Before writing UI

1. Read [references/rules.md](references/rules.md). The usage rules, interaction patterns, accessibility checklist and content style are not optional.
2. Find the component in [references/components.md](references/components.md) (CSS classes with reference markup) or [references/react.md](references/react.md) (React exports). Reuse before inventing. If a component is missing, compose it from existing classes and tokens, and say so.
3. Look up any value in [references/tokens.md](references/tokens.md). Never write a hex colour, an rgb(), or a px value off the 4px scale.
4. Frameworks: run `pnpm exec pw-ui ext list`. Read the reference of every framework whose "applies" line matches the work, whether supported ([references/frameworks/index.md](references/frameworks/index.md)) or project-local (`.pw-ui/frameworks/<name>/reference.md`).

## Install

Run in the project root. Needs `NODE_AUTH_TOKEN` set and the registry lines in `~/.npmrc`, and fails without them; see [guides/install.md](guides/install.md).

```sh
grep -qs '^@precision-weave:registry=' .npmrc || printf '\n@precision-weave:registry=https://npm.pkg.github.com\n' >> .npmrc
pnpm add @pw/ui@npm:@precision-weave/ui
pnpm exec pw-ui install
```

`pw-ui install` copies this skill into the project, writes nothing else, and keeps any file you edited. Running it again changes nothing. Upgrade and CI steps are in [guides/install.md](guides/install.md).

Plain CSS, any stack:

```css
@import "@pw/ui/tokens.css";        /* or @pw/ui/themes/<name>.css for a themed app */
@import "@pw/ui/components.css";
/* @import "@pw/ui/styles/<style>.css";  only when the theme has a style preset, after components.css */
```

React (Vite or Next, React 19, with `lucide-react` installed):

```tsx
import { ThemeProvider, ToastProvider, TooltipProvider, AppShell, TopBar, Brand, SideNav } from "@pw/ui/react";
```

Tailwind v4: `@import "tailwindcss"; @import "@pw/ui/tokens.css"; @import "@pw/ui/tailwind.css";` then `bg-brand`, `text-text-2`, `p-4`, `rounded-md`.

Dark mode: `data-theme="dark"` on `<html>`, or `ThemeProvider` which also follows the system setting. Put the one-line theme script from `ThemeProvider`'s doc comment in `<head>` to avoid a flash.

## Themes

A theme is a small file of seeds and values (`themes/<name>.json` in the pw-ui repository) that a deterministic resolver expands into every token of both modes. `pnpm exec pw-ui theme list` shows the themes; `pw-ui theme show <name>` shows what one sets. To change a theme, derive one for a client, or import one from a palette, web page or design, follow [guides/themes.md](guides/themes.md): `new`, `set`, `check`, `fix`, then build. Never hand-write theme CSS or override `--pw-` variables in an app.

## How to build a screen

1. Pick the page template: list (header, toolbar, table), detail (main plus sticky aside), settings (narrow sections with inline save), dashboard (KPI row then cards), chat (log fills the height, composer at the bottom).
2. Use the shell: `AppShell` with `TopBar` and `SideNav`; the brand slot shows the logo in internal apps and the client's name in client apps.
3. Forms: `Field` wires label, help and error to the control. Validate on blur. People save: use `useDirtyForm` with `FormSection` (inline Save and Cancel, saved confirmation, unsaved-changes guard). Switches apply immediately and say On or Off. Nothing else autosaves.
4. Lists for things people open, tables for things people compare (`DataTable` with sort, selection and a bulk bar). Status is a `Badge` with an icon and a word.
5. One primary button per view. Confirm before destroying with `ConfirmDialog`; the title names the thing, the button says the verb.
6. Loading: skeleton for content arriving in place, spinner with words for an action, progress bar when the amount is known. Empty states say what the screen is for and offer the first step.
7. AI: mark everything the AI produced (`AiTag`, `AiPanel`) until a person edits or accepts it. Chat answers carry sources (`Citation`), `Confidence` (three bars and a word, never a percentage) and `FeedbackButtons`. Drafts go through `DraftReview`. Agent work shows in `ActivityLog` step by step.
8. Write British English in sentence case. Buttons say the verb and the object. Errors say what happened and what to do next. No exclamation marks.

## Check your work

- `npx pw-ui-lint src` (from an app that depends on @pw/ui) flags colour literals, off-scale px, unknown `--pw-` variables and Tailwind arbitrary colours or sizes. A line may carry `/* pw-allow: reason */` when a literal is justified.
- Every interactive element has a visible focus ring; every icon-only button has a label; every status has an icon and a word; every form control has a visible label.
- Check both modes: toggle `data-theme` and look. Dark is lifted, not black; if something is harsh, lower saturation, do not raise contrast.

## Reference

- [references/tokens.md](references/tokens.md): every variable with light and dark values and its use.
- [references/components.md](references/components.md): class index and reference markup for every component, including ARIA.
- [references/react.md](references/react.md): every React export with when to use it; props in `dist/react/*.d.ts`.
- [references/rules.md](references/rules.md): usage rules, interaction patterns, accessibility checklist, content style.
- [references/themes.md](references/themes.md): the themes, and the tokens of each style preset.
- [references/frameworks/index.md](references/frameworks/index.md): supported frameworks and where their references are.
- [guides/install.md](guides/install.md): install, use, CI, upgrade and failures.
- [guides/extend.md](guides/extend.md): try a new framework in this project, then promote it to pw-ui.
- [guides/themes.md](guides/themes.md): change, derive or import a theme with the `pw-ui theme` commands.
- The documentation site in `site/` of the pw-ui repository shows everything live in both modes (`just start`).

These reference files are generated by `pnpm build` in the pw-ui repository. Do not edit them; change the source and rebuild.
